import 'dart:html' as html;                     // Web only
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../homepage.dart';
import 'business_auth_page.dart';
import 'widgets/google_signin_button.dart'
    show GoogleSignInButton, registerGoogleBtnFactory;

const primaryColor = Color(0xFF0018EE);
const errorColor   = Colors.redAccent;
const _role        = 'student';

final GoogleSignIn _gSignIn = GoogleSignIn.standard(
  scopes: ['email', 'profile', 'openid'],
);

class StudentAuthPage extends StatefulWidget {
  const StudentAuthPage({super.key});
  @override State<StudentAuthPage> createState() => _StudentAuthPageState();
}

class _StudentAuthPageState extends State<StudentAuthPage> {
  /// `true` = login, `false` = sign-up
  bool  _login = true;
  bool  _busy  = false;
  String _err  = '';

  // controllers
  final _name  = TextEditingController();
  final _email = TextEditingController();
  final _pass  = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (kIsWeb) {
      registerGoogleBtnFactory();
      _listenWebCredential();
    }
  }

  // ───────── Google credential listener (Web) ─────────
  void _listenWebCredential() {
    html.window.onMessage.listen((event) async {
      final d = event.data;
      if (d is Map && d['credential'] != null) {
        final cred = GoogleAuthProvider.credential(idToken: d['credential']);
        final res  = await FirebaseAuth.instance.signInWithCredential(cred);
        await _finishAuth(res.user, fromGoogle: true);
      }
    });
  }

  // ───────── Google (mobile / desktop) ─────────
  Future<void> _googleMobile() async {
    setState(() { _busy = true; _err = ''; });
    try {
      final acc = await _gSignIn.signIn();
      if (acc == null) { setState(() => _err = 'Google sign-in cancelled'); return; }
      final auth = await acc.authentication;
      final cred = GoogleAuthProvider.credential(
        idToken: auth.idToken, accessToken: auth.accessToken);
      final res = await FirebaseAuth.instance.signInWithCredential(cred);
      await _finishAuth(res.user, fromGoogle: true);
    } catch (e) {
      setState(() => _err = 'Google sign-in failed: $e');
    } finally { setState(() => _busy = false); }
  }

  // ───────── Email / password flows ─────────
  Future<void> _submitEmailPw() async {
    setState(() { _busy = true; _err = ''; });
    try {
      UserCredential cred;
      if (_login) {
        cred = await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: _email.text.trim(), password: _pass.text.trim());
      } else {
        cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: _email.text.trim(), password: _pass.text.trim());
      }
      await _finishAuth(cred.user, fromGoogle: false);
    } on FirebaseAuthException catch (e) {
      setState(() => _err = e.message ?? 'Auth failed');
    } finally { setState(() => _busy = false); }
  }

  // ───────── Common finish ─────────
  Future<void> _finishAuth(User? user, {required bool fromGoogle}) async {
    if (user == null || !mounted) return;

    await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
      'displayName': fromGoogle ? user.displayName : _name.text.trim(),
      'role'       : _role,
    }, SetOptions(merge: true));

    final prefs = await SharedPreferences.getInstance();
    Navigator.pushReplacement(context,
      MaterialPageRoute(builder: (_) => HomePage(
        isDarkMode     : prefs.getBool('isDarkMode') ?? false,
        isDyslexicFont : prefs.getBool('isDyslexicFont') ?? false,
        role           : _role,
      )));
  }

  // ───────── UI ─────────
  @override
  Widget build(BuildContext ctx) => Scaffold(
    appBar: AppBar(title: const Text('Student'),
        backgroundColor: primaryColor, centerTitle: true),
    body: SingleChildScrollView(
      padding: const EdgeInsets.all(32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(child: Image.asset('assets/g-logo.png',
                  height: 120, width: 120)),
          const SizedBox(height: 30),

          // extra field only in sign-up
          if (!_login) ...[
            _field('Name', Icons.person_outline, _name, false),
            const SizedBox(height: 16),
          ],

          _field('E-mail', Icons.email_outlined, _email, false),
          const SizedBox(height: 16),
          _field('Password', Icons.lock_outline, _pass, true),
          const SizedBox(height: 24),

          _button(_login ? 'Login' : 'Create account', _submitEmailPw),
          const SizedBox(height: 16),
          const Center(child: Text('OR',
              style: TextStyle(fontWeight: FontWeight.w600))),
          const SizedBox(height: 16),
          GoogleSignInButton(busy: _busy,
              onPressed: kIsWeb ? null : _googleMobile),

          // toggle link
          TextButton(
            onPressed: _busy ? null : () => setState(() => _login = !_login),
            child: Text(_login
                ? 'New user?  Sign up'
                : 'Have an account?  Login',
                style: const TextStyle(fontWeight: FontWeight.w600)),
          ),

          // link to business page
          TextButton(
            onPressed: _busy ? null : () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const BusinessAuthPage())),
            child: const Text('Business login / register',
                style: TextStyle(fontWeight: FontWeight.w600)),
          ),

          if (_err.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Text(_err, textAlign: TextAlign.center,
                  style: const TextStyle(color: errorColor))),
        ],
      ),
    ),
  );

  // helpers
  Widget _field(String lbl, IconData ico, TextEditingController c, bool obs) =>
      TextField(
        controller: c, obscureText: obs,
        decoration: InputDecoration(
          labelText: lbl,
          prefixIcon: Icon(ico, color: primaryColor),
          filled: true, fillColor: Colors.grey[100],
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        ),
      );

  Widget _button(String txt, VoidCallback fn) => ElevatedButton(
    onPressed: _busy ? null : fn,
    style: ElevatedButton.styleFrom(
        backgroundColor: primaryColor,
        minimumSize: const Size(double.infinity, 50)),
    child: _busy
        ? const CircularProgressIndicator(color: Colors.white)
        : Text(txt, style: const TextStyle(fontSize: 18)),
  );
}
