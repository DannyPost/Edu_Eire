import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'dart:html' as html;

const _viewType = 'google-signin-html';

void registerGoogleBtnFactory() {
  // ignore: undefined_prefixed_name
  ui.platformViewRegistry.registerViewFactory(_viewType, (int viewId) {
    // ...button code...
  });
}

class GoogleSignInButton extends StatelessWidget {
  final bool busy;
  final VoidCallback? onPressed;
  const GoogleSignInButton({super.key, this.busy = false, this.onPressed});
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity, height: 48,
      child: AbsorbPointer(
        absorbing: busy,
        child: HtmlElementView(viewType: _viewType),
      ),
    );
  }
}
