// Conditional export wrapper – nothing else here.
export 'google_signin_stub.dart'
    if (dart.library.html) 'google_signin_web.dart'
    if (dart.library.io)  'google_signin_mobile.dart';

void registerGoogleBtnFactory() {}      // stub for non-html/non-io targets
