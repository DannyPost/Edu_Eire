// widgets/google_signin_mobile.dart
import 'package:flutter/material.dart';

class GoogleSignInButton extends StatelessWidget {
  final bool busy;
  final VoidCallback? onPressed;
  const GoogleSignInButton({super.key, this.busy = false, this.onPressed});
  @override
  Widget build(BuildContext context) => SizedBox(
    width: double.infinity, height: 48,
    child: ElevatedButton.icon(
      onPressed: busy ? null : onPressed,
      icon: Image.asset('assets/g-logo.png', height: 22, width: 22),
      label: Text('Sign in with Google', style: TextStyle(fontWeight: FontWeight.w600)),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white, foregroundColor: Colors.black87,
        side: BorderSide(color: Colors.black12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    ),
  );
}
