import 'package:flutter/material.dart';
import 'dart:html' as html;
import 'dart:ui' as ui;

const _viewType = 'google-signin-html';

// Registers the custom view only ONCE (for Flutter web)
// DO NOT import or use this file directly, only use via google_signin_button.dart!
void registerGoogleBtnFactory() {
  // ignore: undefined_prefixed_name
  ui.platformViewRegistry.registerViewFactory(_viewType, (int viewId) {
    final button = html.DivElement()
      ..id = 'google-signin-btn'
      ..style.width = '100%'
      ..style.height = '48px'
      ..style.display = 'flex'
      ..style.justifyContent = 'center'
      ..style.alignItems = 'center';

    // Inject Google's official button HTML/JS
    button.setInnerHtml('''
      <div id="g_id_onload"
           data-client_id="21657212241-s031j74rca545f8mv94cn99rcv5da4st.apps.googleusercontent.com"
           data-callback="onGoogleSignIn"
           data-auto_prompt="false">
      </div>
      <div class="g_id_signin"
           data-type="standard"
           data-size="large"
           data-theme="outline"
           data-text="sign_in_with"
           data-shape="rect"
           data-logo_alignment="left">
      </div>
      <script>
        window.onGoogleSignIn = (res) => {
          window.parent.postMessage({credential: res.credential}, "*");
        };
      </script>
    ''', treeSanitizer: html.NodeTreeSanitizer.trusted);

    return button;
  });
}

class GoogleSignInButton extends StatelessWidget {
  final bool busy;
  final VoidCallback? onPressed; // Not used for web, needed for signature compatibility
  const GoogleSignInButton({super.key, this.busy = false, this.onPressed});
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 48,
      child: AbsorbPointer(
        absorbing: busy,
        child: HtmlElementView(viewType: _viewType),
      ),
    );
  }
}
