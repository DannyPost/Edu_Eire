import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

import 'signup_page.dart';                       // same folder
import 'admin_dashboard_page.dart';              // renamed file / class

// ─── UI colours ───────────────────────────────────────────────────────────────
const Color primaryColor = Color(0xFF4595e6);
const Color accentColor  = Color(0xFF03DAC6);
const Color textColor    = Color(0xFF424242);
const Color errorColor   = Colors.redAccent;

// ─── Google Sign-In (v7+) ─────────────────────────────────────────────────────
final GoogleSignIn _googleSignIn = GoogleSignIn.standard(
  scopes: ['email', 'profile', 'openid'],
  // clientId set in Firebase console for Web build → no need here
);

// ─── ADMIN LOGIN PAGE ─────────────────────────────────────────────────────────
class AdminLoginPage extends StatefulWidget {
  const AdminLoginPage({super.key});

  @override
  State<AdminLoginPage> createState() => _AdminLoginPageState();
}

class _AdminLoginPageState extends State<AdminLoginPage> {
  final _emailCtrl = TextEditingController();
  final _passCtrl  = TextEditingController();
  String _error    = '';
  bool   _busy     = false;

  // ── Email / Password login ─────────────────────────────────────────────────
  Future<void> _login() async {
    setState(() { _busy = true; _error = ''; });
    try {
      final cred  = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _emailCtrl.text.trim(),
        password: _passCtrl.text,
      );
      final email = cred.user?.email;
      if (email == null) throw Exception('No email found.');

      final snap = await FirebaseFirestore.instance
          .collection('admins')
          .where('email', isEqualTo: email)
          .limit(1)
          .get();

      if (snap.docs.isEmpty) {
        // not registered → go to signup
        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => SignupPage(email: email)),
        );
        return;
      }

      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => AdminDashboardPage(adminEmail: email),
        ),
      );
    } on FirebaseAuthException catch (e) {
      setState(() => _error = e.message ?? 'An unknown error occurred.');
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      setState(() => _busy = false);
    }
  }

  // ── Google Sign-In login ───────────────────────────────────────────────────
  Future<void> _google() async {
    setState(() { _busy = true; _error = ''; });
    try {
      final acc = await _googleSignIn.signIn();
      if (acc == null) { setState(() => _error = 'Google sign-in cancelled.'); return; }

      final auth = await acc.authentication;
      final cred = GoogleAuthProvider.credential(
        accessToken: auth.accessToken,
        idToken: auth.idToken,
      );
      final res   = await FirebaseAuth.instance.signInWithCredential(cred);
      final email = res.user?.email;
      if (email == null) throw Exception('No email found.');

      final snap = await FirebaseFirestore.instance
          .collection('admins')
          .where('email', isEqualTo: email)
          .limit(1)
          .get();

      if (snap.docs.isEmpty) {
        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => SignupPage(email: email)),
        );
        return;
      }

      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => AdminDashboardPage(adminEmail: email),
        ),
      );
    } catch (e) {
      setState(() => _error = 'Google sign-in failed: $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  // ── UI ─────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Edu Éire', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: primaryColor,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(child: Image.asset('assets/logo.png', height: 120, width: 120, errorBuilder: (_,__,___)=>const SizedBox(height:60))),
            const SizedBox(height: 30),
            Text('Login to your admin account', textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: textColor)),
            const SizedBox(height: 20),
            _field('Email', Icons.email_outlined, _emailCtrl, false),
            const SizedBox(height: 16),
            _field('Password', Icons.lock_outline, _passCtrl, true),
            const SizedBox(height: 24),
            _button('Login', _login),
            const SizedBox(height: 16),
            _googleButton(),
            const SizedBox(height: 24),
            TextButton(
              onPressed: _busy ? null : () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SignupPage()),
              ),
              child: const Text("Don't have an account? Sign up",
                  style: TextStyle(color: primaryColor, fontSize: 16, fontWeight: FontWeight.w600)),
            ),
            if (_error.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 24),
                child: Text(_error, textAlign: TextAlign.center,
                    style: const TextStyle(color: errorColor, fontSize: 14)),
              ),
          ],
        ),
      ),
    );
  }

  TextField _field(String label, IconData icon, TextEditingController ctrl, bool obscure) => TextField(
        controller: ctrl,
        obscureText: obscure,
        keyboardType: TextInputType.emailAddress,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon, color: primaryColor),
          filled: true,
          fillColor: Colors.grey[100],
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
        ),
      );

  ElevatedButton _button(String text, VoidCallback onTap) => ElevatedButton(
        onPressed: _busy ? null : onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryColor,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 55),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        child: _busy ? const CircularProgressIndicator(color: Colors.white) : Text(text, style: const TextStyle(fontSize: 18)),
      );

  ElevatedButton _googleButton() => ElevatedButton.icon(
        icon: Image.asset('assets/g-logo.png', height: 24, width: 24,
            errorBuilder: (_, __, ___) => const Icon(Icons.account_circle, color: primaryColor)),
        label: const Text('Continue with Google', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: textColor,
          minimumSize: const Size(double.infinity, 55),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: const BorderSide(color: Colors.grey, width: 0.5),
          ),
        ),
        onPressed: _busy ? null : _google,
      );
}
