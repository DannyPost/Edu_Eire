import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../studentdeals/product_model.dart';
import '../studentdeals/student_deals_page.dart';

// ─── colours ──────────────────────────────────────────────────────────────────
const Color kPrimaryBlue = Color(0xFF4595e6);
const Color kLightBlue = Color(0xFFe7f2fb);

// ─── DASHBOARD ───────────────────────────────────────────────────────────────
class AdminDashboardPage extends StatefulWidget {
  final String adminEmail;
  const AdminDashboardPage({super.key, required this.adminEmail});

  @override
  State<AdminDashboardPage> createState() => _AdminDashboardPageState();
}

class _AdminDashboardPageState extends State<AdminDashboardPage> {
  final _titleCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _priceCtrl = TextEditingController();
  final _supplyCtrl = TextEditingController();

  final List<String> sectors = [
    'Tech', 'Food & Drink', 'Fitness & Wellness', 'Fashion & Style',
    'Education & Courses', 'Entertainment', 'Travel', 'Beauty & Skincare',
    'Books & Stationery', 'Health Services', 'Music & Events',
    'Gaming & E-sports', 'Home & Living', 'Finance & Banking',
    'Student Essentials', 'Streaming & Subscriptions', 'Careers & Internships',
    'Gyms & Sports Clubs', 'Transport & Bikes'
  ];
  final List<String> locations = [
    'Carlow','Cavan','Clare','Cork','Donegal','Dublin','Galway','Kerry','Kildare',
    'Kilkenny','Laois','Leitrim','Limerick','Longford','Louth','Mayo','Meath',
    'Monaghan','Offaly','Roscommon','Sligo','Tipperary','Waterford','Westmeath',
    'Wexford','Wicklow','Online'
  ];
  final List<String> modes = ['Online', 'In-store'];

  List<String> selSectors = [];
  List<String> selLocations = [];
  List<String> selModes = [];

  Future<void> _delete(String id) async {
    await FirebaseFirestore.instance.collection('products').doc(id).delete();
  }

  Future<void> _addProduct() async {
    if (_titleCtrl.text.isEmpty || _descCtrl.text.isEmpty || _priceCtrl.text.isEmpty || _supplyCtrl.text.isEmpty ||
        selSectors.isEmpty || selLocations.isEmpty || selModes.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please fill in all fields.')));
      return;
    }

    final id = DateTime.now().millisecondsSinceEpoch.toString();
    await FirebaseFirestore.instance.collection('products').doc(id).set({
      'id': id,
      'adminId': widget.adminEmail,
      'title': _titleCtrl.text,
      'description': _descCtrl.text,
      'price': double.tryParse(_priceCtrl.text) ?? 0,
      'supply': int.tryParse(_supplyCtrl.text) ?? 0,
      'sector': selSectors.join(', '),
      'location': selLocations.join(', '),
      'mode': selModes.join(', '),
    });

    setState(() {
      _titleCtrl.clear();
      _descCtrl.clear();
      _priceCtrl.clear();
      _supplyCtrl.clear();
      selSectors.clear();
      selLocations.clear();
      selModes.clear();
    });
  }

  Widget _filterChips(List<String> options, List<String> selected) => Wrap(
    spacing: 6,
    children: options.map((o) {
      final on = selected.contains(o);
      return FilterChip(
        label: Text(o),
        selected: on,
        backgroundColor: kLightBlue,
        selectedColor: kPrimaryBlue,
        labelStyle: TextStyle(color: on ? Colors.white : kPrimaryBlue),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        onSelected: (_) => setState(() => on ? selected.remove(o) : selected.add(o)),
      );
    }).toList(),
  );

  @override
  Widget build(BuildContext ctx) => Scaffold(
    backgroundColor: kLightBlue,
    appBar: AppBar(
      title: const Text('Admin Dashboard'),
      backgroundColor: kPrimaryBlue,
    ),
    drawer: _drawer(ctx),
    body: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(
        children: [
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  TextField(controller: _titleCtrl, decoration: const InputDecoration(labelText: 'Title')),
                  TextField(controller: _descCtrl, decoration: const InputDecoration(labelText: 'Description')),
                  TextField(controller: _priceCtrl, decoration: const InputDecoration(labelText: 'Price'),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true)),
                  TextField(controller: _supplyCtrl, decoration: const InputDecoration(labelText: 'Supply'),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true)),
                  const SizedBox(height: 10),
                  _filterChips(sectors, selSectors),
                  _filterChips(locations, selLocations),
                  _filterChips(modes, selModes),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kPrimaryBlue,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: _addProduct,
                      child: const Text('Add Product', style: TextStyle(fontWeight: FontWeight.w600)),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const Divider(),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('products')
                  .where('adminId', isEqualTo: widget.adminEmail)
                  .snapshots(),
              builder: (ctx, snap) {
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                final products = snap.data!.docs
                    .map((d) => Product.fromMap(d.data() as Map<String, dynamic>))
                    .toList();
                return ListView.builder(
                  itemCount: products.length,
                  itemBuilder: (_, i) {
                    final p = products[i];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                      child: ListTile(
                        title: Text(p.title, style: const TextStyle(color: kPrimaryBlue, fontWeight: FontWeight.w600)),
                        subtitle: Text('${p.sector} • ${p.location} • ${p.mode}',
                            style: TextStyle(color: Colors.grey[700])),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text('€${p.price.toStringAsFixed(2)}',
                                style: const TextStyle(color: kPrimaryBlue, fontWeight: FontWeight.bold)),
                            IconButton(icon: const Icon(Icons.delete), color: Colors.red, onPressed: () => _delete(p.id)),
                          ],
                        ),
                        onTap: () => _showEditDialog(p),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    ),
  );

  Drawer _drawer(BuildContext ctx) => Drawer(
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(topRight: Radius.circular(28), bottomRight: Radius.circular(28))),
    backgroundColor: kLightBlue,
    child: ListView(
      padding: EdgeInsets.zero,
      children: [
        DrawerHeader(
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [kPrimaryBlue, kLightBlue],
                begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: const BorderRadius.only(bottomRight: Radius.circular(36)),
          ),
          child: const Align(
            alignment: Alignment.bottomLeft,
            child: Text('Admin Menu', style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w700)),
          ),
        ),
        ListTile(
          leading: const Icon(Icons.dashboard, color: kPrimaryBlue),
          title: const Text('Admin Dashboard', style: TextStyle(fontWeight: FontWeight.w500)),
          selected: ModalRoute.of(ctx)?.settings.name == '/admin',
          selectedTileColor: Colors.grey[200],
          onTap: () {
            Navigator.pop(ctx);
          },
        ),
        ListTile(
          leading: const Icon(Icons.local_offer, color: kPrimaryBlue),
          title: const Text('Student Deals', style: TextStyle(fontWeight: FontWeight.w500)),
          onTap: () {
            Navigator.pop(ctx);
            Navigator.pushReplacement(
              ctx,
              MaterialPageRoute(builder: (_) => const StudentDealsPage()),
            );
          },
        ),
      ],
    ),
  );

  void _showEditDialog(Product p) {
    final t = TextEditingController(text: p.title);
    final d = TextEditingController(text: p.description);
    final pr = TextEditingController(text: p.price.toString());
    final su = TextEditingController(text: p.supply.toString());
    List<String> eSec = p.sector.split(', ');
    List<String> eLoc = p.location.split(', ');
    List<String> eMod = p.mode.split(', ');

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        backgroundColor: kLightBlue,
        title: const Text('Edit Product'),
        content: SingleChildScrollView(
          child: Column(children: [
            TextField(controller: t, decoration: const InputDecoration(labelText: 'Title')),
            TextField(controller: d, decoration: const InputDecoration(labelText: 'Description')),
            TextField(controller: pr, decoration: const InputDecoration(labelText: 'Price'),
                keyboardType: const TextInputType.numberWithOptions(decimal: true)),
            TextField(controller: su, decoration: const InputDecoration(labelText: 'Supply'),
                keyboardType: const TextInputType.numberWithOptions(decimal: true)),
            const SizedBox(height: 10),
            _filterChips(sectors, eSec),
            _filterChips(locations, eLoc),
            _filterChips(modes, eMod),
          ]),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              style: TextButton.styleFrom(foregroundColor: kPrimaryBlue),
              child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: kPrimaryBlue,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            onPressed: () async {
              await FirebaseFirestore.instance.collection('products').doc(p.id).update({
                'title': t.text,
                'description': d.text,
                'price': double.tryParse(pr.text) ?? 0,
                'supply': int.tryParse(su.text) ?? 0,
                'sector': eSec.join(', '),
                'location': eLoc.join(', '),
                'mode': eMod.join(', '),
              });
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }
}
