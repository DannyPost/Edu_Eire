import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';   // ← correct package
import 'package:url_launcher/url_launcher.dart';

import 'admin_dashboard_page.dart';

const Color primaryColor = Color(0xFF4595e6);
const Color errorColor   = Colors.redAccent;

class SignupPage extends StatefulWidget {
  final String? email;
  const SignupPage({super.key, this.email});

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final _formKey     = GlobalKey<FormState>();
  late  TextEditingController _emailCtrl;
  final _passCtrl    = TextEditingController();
  final _bizNameCtrl = TextEditingController();
  final _sectorCtrl  = TextEditingController();
  final _sizeCtrl    = TextEditingController();

  bool   _busy = false;
  String? _err;

  @override
  void initState() {
    super.initState();
    _emailCtrl = TextEditingController(text: widget.email ?? '');
  }

  Future<void> _signup() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() { _busy = true; _err = null; });

    try {
      // 1️⃣ Auth user
      final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailCtrl.text.trim(),
        password: _passCtrl.text.trim(),
      );

      // 2️⃣ Call Stripe connect function
      final callable = FirebaseFunctions.instanceFor(region: 'europe-west1')
          .httpsCallable('createStripeConnectAccount');

      final res = await callable.call({
        'email'       : _emailCtrl.text.trim(),
        'businessName': _bizNameCtrl.text.trim(),
      });

      final acctId     = res.data['stripeAccountId'];
      final onboardUrl = res.data['onboardingUrl'];

      // 3️⃣ Store in Firestore
      await FirebaseFirestore.instance.collection('admins').doc(cred.user!.uid).set({
        'email'          : _emailCtrl.text.trim(),
        'businessName'   : _bizNameCtrl.text.trim(),
        'sector'         : _sectorCtrl.text.trim(),
        'size'           : _sizeCtrl.text.trim(),
        'stripeAccountId': acctId,
        'approved'       : false,
        'created'        : DateTime.now().toIso8601String(),
      });

      // 4️⃣ Launch onboarding
      final uri = Uri.parse(onboardUrl);
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw 'Could not launch onboarding link';
      }

      if (!mounted) return;
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Signup complete'),
          content: const Text('Finish Stripe onboarding. You’ll get an approval email soon.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))
          ],
        ),
      );
    } on FirebaseAuthException catch (e) {
      setState(() => _err = e.message);
    } catch (e) {
      setState(() => _err = e.toString());
    } finally {
      setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passCtrl.dispose();
    _bizNameCtrl.dispose();
    _sectorCtrl.dispose();
    _sizeCtrl.dispose();
    super.dispose();
  }

  // ─── UI ─────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext ctx) => Scaffold(
        appBar: AppBar(title: const Text('Business Signup'), backgroundColor: primaryColor),
        body: Padding(
          padding: const EdgeInsets.all(18),
          child: Center(
            child: SingleChildScrollView(
              child: Form(
                key: _formKey,
                child: Column(
                  children: [
                    const Text('Sign up as a business',
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 22),

                    _field(_emailCtrl, 'Email', false,
                        (v) => v == null || !v.contains('@') ? 'Invalid email' : null),
                    _field(_passCtrl, 'Password', true,
                        (v) => v == null || v.length < 6 ? 'Min 6 chars' : null),
                    const Divider(height: 32),
                    _field(_bizNameCtrl, 'Business Name', false,
                        (v) => v == null || v.isEmpty ? 'Required' : null),
                    _field(_sectorCtrl, 'Sector', false,
                        (v) => v == null || v.isEmpty ? 'Required' : null),
                    _field(_sizeCtrl, 'Business Size', false,
                        (v) => v == null || v.isEmpty ? 'Required' : null),

                    if (_err != null) ...[
                      const SizedBox(height: 14),
                      Text(_err!, style: const TextStyle(color: errorColor)),
                    ],
                    const SizedBox(height: 18),
                    _busy
                        ? const CircularProgressIndicator()
                        : ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: primaryColor,
                              minimumSize: const Size(double.infinity, 44),
                            ),
                            onPressed: _signup,
                            child: const Text('Submit & Start Stripe Onboarding'),
                          ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );

  TextFormField _field(TextEditingController ctrl, String label, bool obscure,
          String? Function(String?) validator) =>
      TextFormField(
        controller: ctrl,
        obscureText: obscure,
        decoration: InputDecoration(labelText: label),
        validator: validator,
      );
}
