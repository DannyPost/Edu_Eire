// lib/studybot/net/api_client.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/env.dart';

typedef TokenProvider = Future<String> Function();

class ApiClient {
  final String baseUrl;
  final TokenProvider tokenProvider;

  ApiClient({
    String? baseUrl,
    TokenProvider? tokenProvider,
  })  : baseUrl = (baseUrl ?? Env.apiBase).replaceAll(RegExp(r'/+$'), ''),
        tokenProvider = tokenProvider ?? Env.firebaseIdToken;

  Future<Map<String, dynamic>> post(String path, Map<String, dynamic> body) async {
    final token = await tokenProvider();
    final uri = Uri.parse('$baseUrl${_normalizePath(path)}');

    final res = await http.post(
      uri,
      headers: {
        'Content-Type': 'application/json',
        if (token.isNotEmpty) 'Authorization': 'Bearer $token',
      },
      body: jsonEncode(body),
    );

    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('HTTP ${res.statusCode} ${res.reasonPhrase}: ${res.body}');
    }
    final dynamic json = res.body.isEmpty ? {} : jsonDecode(res.body);
    if (json is Map<String, dynamic>) return json;
    throw Exception('Unexpected JSON from ${uri.path}: ${res.body}');
  }

  String _normalizePath(String path) => path.isEmpty
      ? ''
      : (path.startsWith('/') ? path : '/$path');
}