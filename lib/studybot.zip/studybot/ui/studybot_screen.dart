// lib/studybot/ui/studybot_screen.dart
import 'package:flutter/material.dart';

import '../config/env.dart';
import '../net/api_client.dart';
import '../services/studybot_service.dart';
import '../models/chat_types.dart';

class StudyBotScreen extends StatefulWidget {
  const StudyBotScreen({super.key});

  @override
  State<StudyBotScreen> createState() => _StudyBotScreenState();
}

class _StudyBotScreenState extends State<StudyBotScreen> {
  final _prompt = TextEditingController(
    text: 'Compare how power is presented in Ozymandias and My Last Duchess.',
  );
  final _subject = TextEditingController(text: 'English');
  final _level   = TextEditingController(text: 'HL');

  bool _busy = false;
  String? _resultTitle;
  String? _resultBody;

  late final ApiClient _client;
  late final StudyBotService _sb;

  @override
  void initState() {
    super.initState();
    _client = ApiClient(
      tokenProvider: Env.firebaseIdToken, // replace with your Firebase flow if needed
    );
    _sb = StudyBotService(_client);
  }

  Future<void> _run() async {
    setState(() {
      _busy = true;
      _resultTitle = null;
      _resultBody = null;
    });

    try {
      final res = await _sb.routeAndExecute(
        message: _prompt.text.trim(),
        meta: {
          'subject': _subject.text.trim(),
          'level': _level.text.trim(),
        },
      );

      switch (res.task) {
        case ChatTask.advice: {
          final r = res.payload as AdviceResponse;
          _resultTitle = 'Advice';
          _resultBody  = r.text;
          break;
        }
        case ChatTask.exemplar: {
          final r = res.payload as ExemplarResponse;
          _resultTitle = 'Exemplar';
          _resultBody  = r.text;
          break;
        }
        case ChatTask.paper: {
          final r = res.payload as PaperResponse;
          _resultTitle = 'Paper';
          _resultBody  = r.text;
          break;
        }
        case ChatTask.grade: {
          final r = res.payload as GradeResponse;
          final tips = r.bullets.isNotEmpty ? '\n\nTips:\n- ${r.bullets.join('\n- ')}' : '';
          final rub  = (r.rubricId != null && r.rubricId!.isNotEmpty) ? '\nRubric: ${r.rubricId}' : '';
          final cmt  = (r.comment != null && r.comment!.isNotEmpty) ? '\n\n${r.comment}' : '';
          _resultTitle = 'Grade';
          _resultBody  = 'Score: ${r.score.toStringAsFixed(1)}$rub$tips$cmt';
          break;
        }
      }
    } catch (e) {
      _resultTitle = 'Error';
      _resultBody  = e.toString();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _prompt.dispose();
    _subject.dispose();
    _level.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final btn = FilledButton(
      onPressed: _busy ? null : _run,
      child: _busy
          ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
          : const Text('Ask StudyBot'),
    );

    return Scaffold(
      appBar: AppBar(title: const Text('StudyBot')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            TextField(
              controller: _prompt,
              maxLines: 4,
              decoration: const InputDecoration(
                labelText: 'Your question / prompt',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _subject,
                    decoration: const InputDecoration(
                      labelText: 'Subject (e.g., English)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: _level,
                    decoration: const InputDecoration(
                      labelText: 'Level (e.g., HL/OL)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Align(alignment: Alignment.centerRight, child: btn),
            const SizedBox(height: 16),
            if (_resultTitle != null) ...[
              Text(_resultTitle!, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              SelectableText(
                _resultBody ?? '',
                style: const TextStyle(fontFamily: 'monospace'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}