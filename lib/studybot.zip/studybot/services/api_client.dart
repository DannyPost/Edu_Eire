// lib/studybot/services/api_client.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/env.dart';

class ApiClient {
  ApiClient();

  String get _base =>
      Env.apiBase.replaceAll(RegExp(r'/+$'), ''); // trim trailing slash

  Future<Map<String, String>> _headers() async {
    final headers = <String, String>{
      'Content-Type': 'application/json',
    };
    if (Env.useJwtAuth) {
      final token = await Env.tokenProvider(); // String
      if (token.isNotEmpty) {
        headers['Authorization'] = 'Bearer $token';
      }
    }
    return headers;
  }

  Uri _u(String path) => Uri.parse('$_base${path.startsWith('/') ? '' : '/'}$path');

  Future<Map<String, dynamic>> get(String path) async {
    final res = await http.get(_u(path), headers: await _headers());
    return _decode(res);
  }

  Future<Map<String, dynamic>> post(String path, Map<String, dynamic> body) async {
    final res = await http.post(_u(path),
        headers: await _headers(), body: jsonEncode(body));
    return _decode(res);
  }

  Map<String, dynamic> _decode(http.Response r) {
    final status = r.statusCode;
    final text = r.body;
    if (status < 200 || status >= 300) {
      throw Exception('HTTP $status: $text');
    }
    if (text.isEmpty) return <String, dynamic>{};
    final decoded = jsonDecode(text);
    if (decoded is Map<String, dynamic>) return decoded;
    return {'data': decoded};
  }
}