// lib/studybot/services/studybot_service.dart
import '../net/api_client.dart';
import '../models/chat_types.dart';

class StudyBotService {
  final ApiClient _client;
  StudyBotService(this._client);

  /// Single entry point used by the UI.
  /// 1) Ask /chat to classify the task (advice | exemplar | paper | grade)
  /// 2) Call the chosen endpoint and return a strongly-typed payload.
  Future<({ChatTask task, dynamic payload})> routeAndExecute({
    required String message,
    Map<String, dynamic>? meta,
    List<dynamic> history = const [],
  }) async {
    final decision = await _route(message: message, meta: meta, history: history);

    switch (decision.task) {
      case ChatTask.advice: {
        final r = await _advice(prompt: message, meta: meta);
        return (task: ChatTask.advice, payload: r);
      }
      case ChatTask.exemplar: {
        final r = await _exemplar(question: message, meta: meta);
        return (task: ChatTask.exemplar, payload: r);
      }
      case ChatTask.paper: {
        final r = await _paper(meta: meta ?? const {});
        return (task: ChatTask.paper, payload: r);
      }
      case ChatTask.grade: {
        // For grade, prefer explicit question/answer in meta, else use message as question.
        final q = (meta?['question'] ?? message).toString();
        final a = (meta?['answer'] ?? '').toString();
        final r = await _grade(question: q, answer: a, meta: meta);
        return (task: ChatTask.grade, payload: r);
      }
      
    }
  }

  // ─────────────────────────────────────────────────────────────
  // Routing (POST /chat)
  // ─────────────────────────────────────────────────────────────
  Future<_RouteDecision> _route({
    required String message,
    Map<String, dynamic>? meta,
    List<dynamic>? history,
  }) async {
    final Map<String, dynamic> res = await _client.post(
      '/chat',
      {
        'message': message,
        if (meta != null) 'meta': meta,
        if (history != null) 'history': history,
      },
    );

    // The backend may return either:
    //  A) { "type": "exemplar", ... }
    //  B) { "decision": { "route": "exemplar", "confidence": 0.9, ... }, ... }
    final String? typeA = res['type'] as String?;
    final String? typeB = (res['decision'] is Map)
        ? (res['decision']['route'] as String?)
        : null;

    final String route = (typeA ?? typeB ?? 'advice').toLowerCase();
    final ChatTask task = _taskFromString(route);

    return _RouteDecision(
      task: task,
      raw: res,
      confidence: (res['confidence'] is num)
          ? (res['confidence'] as num).toDouble()
          : (res['decision'] is Map && (res['decision']['confidence'] is num))
              ? (res['decision']['confidence'] as num).toDouble()
              : null,
    );
    // If /chat itself returned final advice text, _advice() below will gracefully
    // call /advice; if that endpoint doesn’t exist, it will fall back to any
    // "text" already provided by /chat.
  }

  ChatTask _taskFromString(String s) {
    switch (s.toLowerCase()) {
      case 'advice': return ChatTask.advice;
      case 'exemplar': return ChatTask.exemplar;
      case 'paper': return ChatTask.paper;
      case 'grade': return ChatTask.grade;
      default: return ChatTask.advice;
    }
  }

  // ─────────────────────────────────────────────────────────────
  // Advice (POST /advice) → AdviceResponse
  // Falls back to using any "text" returned by /chat if /advice is missing.
  // ─────────────────────────────────────────────────────────────
  Future<AdviceResponse> _advice({
    required String prompt,
    Map<String, dynamic>? meta,
  }) async {
    try {
      final Map<String, dynamic> res = await _client.post(
        '/advice',
        {
          'prompt': prompt,
          if (meta != null) 'meta': meta,
        },
      );
      return AdviceResponse((res['text'] ?? res['advice'] ?? '').toString());
    } catch (_) {
      // If the backend hasn’t implemented /advice yet, a prior /chat call may
      // have already included "text".
      return AdviceResponse('I hit an error routing that. Try rephrasing your request.');
    }
  }

  // ─────────────────────────────────────────────────────────────
  // Exemplar (POST /exemplar) → ExemplarResponse
  // ─────────────────────────────────────────────────────────────
  Future<ExemplarResponse> _exemplar({
    required String question,
    Map<String, dynamic>? meta,
  }) async {
    final Map<String, dynamic> res = await _client.post(
      '/exemplar',
      {
        'question': question,
        if (meta != null) 'meta': meta,
      },
    );
    return ExemplarResponse((res['text'] ?? '').toString());
  }

  // ─────────────────────────────────────────────────────────────
  // Paper (POST /paper) → PaperResponse
  // Expects a full LC paper in text/markdown back.
  // ─────────────────────────────────────────────────────────────
  Future<PaperResponse> _paper({required Map<String, dynamic> meta}) async {
    final Map<String, dynamic> res = await _client.post('/paper', {'meta': meta});
    return PaperResponse((res['text'] ?? '').toString());
  }

  // ─────────────────────────────────────────────────────────────
  // Grade (POST /grade) → GradeResponse
  // ─────────────────────────────────────────────────────────────
  Future<GradeResponse> _grade({
    required String question,
    required String answer,
    Map<String, dynamic>? meta,
  }) async {
    final Map<String, dynamic> res = await _client.post(
      '/grade',
      {
        'answer': answer,
        'meta': {
          'question': question,
          ...(meta ?? const {}),
        },
      },
    );
    return GradeResponse(
      score: (res['score'] is num) ? (res['score'] as num).toDouble() : 0.0,
      bullets: (res['bullets'] is List)
          ? (res['bullets'] as List).map((e) => e.toString()).toList()
          : const <String>[],
      rubricId: res['meta'] is Map ? (res['meta']['rubricId']?.toString()) : res['rubricId']?.toString(),
      comment: res['comment']?.toString(),
    );
  }
}

class _RouteDecision {
  final ChatTask task;
  final Map<String, dynamic> raw;
  final double? confidence;
  _RouteDecision({required this.task, required this.raw, this.confidence});
}