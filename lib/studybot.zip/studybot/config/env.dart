// lib/studybot/config/env.dart
typedef TokenProvider = Future<String> Function();

class Env {
  /// Base URL for your API Gateway (no trailing slash)
  static const String apiBase =
      String.fromEnvironment('STUDYBOT_API_BASE',
          defaultValue:
              'https://57u97hpdwi.execute-api.eu-west-1.amazonaws.com/dev');

  /// If true, adds `Authorization: Bearer <idToken>` header using [tokenProvider].
  static const bool useJwtAuth = true;

  /// Function that returns the current Firebase ID token.
  /// Assign this in main.dart **after** Firebase.initializeApp.
  static TokenProvider tokenProvider = _defaultNoAuth;

  static Future<String> _defaultNoAuth() async => '';
}