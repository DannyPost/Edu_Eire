// lib/studybot/models/chat_types.dart
enum ChatTask { advice, exemplar, paper, grade }

class AdviceResponse {
  final String text;
  AdviceResponse(this.text);
}

class ExemplarResponse {
  final String text;
  ExemplarResponse(this.text);
}

class PaperResponse {
  final String text;
  PaperResponse(this.text);
}

class GradeResponse {
  final double score;              // 0.0–100.0
  final List<String> bullets;      // short tips
  final String? rubricId;          // optional rubric key
  final String? comment;           // optional marker comment
  GradeResponse({
    required this.score,
    this.bullets = const [],
    this.rubricId,
    this.comment,
  });
}