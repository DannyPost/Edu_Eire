class Message {
  final String role; // 'user' or 'bot'
  final String text;

  Message({required this.role, required this.text});
}
