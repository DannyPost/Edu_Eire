import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';
import 'product_model.dart';

class StudentDealsPage extends StatefulWidget {
  final String? adminId;
  const StudentDealsPage({super.key, this.adminId});

  @override
  State<StudentDealsPage> createState() => _StudentDealsPageState();
}

class _StudentDealsPageState extends State<StudentDealsPage> {
  Set<String> selectedSectors = {};
  Set<String> selectedLocations = {};
  Set<String> selectedModes = {};
  final Map<Product, int> cart = {};

  final List<String> sectors = [
    'All Sectors', 'Tech', 'Food & Drink', 'Fitness & Wellness', 'Fashion & Style',
    'Education & Courses', 'Entertainment', 'Travel', 'Beauty & Skincare',
    'Books & Stationery', 'Health Services', 'Music & Events',
    'Gaming & E-sports', 'Home & Living', 'Finance & Banking',
    'Student Essentials', 'Streaming & Subscriptions', 'Careers & Internships',
    'Gyms & Sports Clubs', 'Transport & Bikes'
  ];

  final List<String> locations = [
    'All Locations', 'Carlow', 'Cavan', 'Clare', 'Cork', 'Donegal', 'Dublin', 'Galway',
    'Kerry', 'Kildare', 'Kilkenny', 'Laois', 'Leitrim', 'Limerick',
    'Longford', 'Louth', 'Mayo', 'Meath', 'Monaghan', 'Offaly', 'Roscommon',
    'Sligo', 'Tipperary', 'Waterford', 'Westmeath', 'Wexford', 'Wicklow', 'Online'
  ];

  final List<String> modes = ['All Modes', 'Online', 'In-store'];

  void toggleFilter(Set<String> filterSet, String value, String allValue) {
    setState(() {
      if (value == allValue) {
        filterSet.clear();
        filterSet.add(value);
      } else {
        filterSet.remove(allValue);
        if (!filterSet.add(value)) {
          filterSet.remove(value);
        }
      }
    });
  }

  void addToCart(Product product) {
    setState(() {
      if (!cart.containsKey(product)) {
        cart[product] = 1;
      } else if (cart[product]! < product.supply) {
        cart[product] = cart[product]! + 1;
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Cannot add more than available supply.')),
        );
      }
    });
  }

  void checkout() async {
    bool allPaymentsSuccessful = true;
    for (final entry in cart.entries) {
      final product = entry.key;
      final qty = entry.value;
      if (product.stripeUrl != null && product.stripeUrl!.isNotEmpty) {
        final Uri paymentUri = Uri.parse(product.stripeUrl!);
        if (await canLaunchUrl(paymentUri)) {
          final launched = await launchUrl(paymentUri, mode: LaunchMode.externalApplication);
          if (!launched) {
            allPaymentsSuccessful = false;
            break;
          }
        } else {
          allPaymentsSuccessful = false;
          break;
        }
      }
    }

    if (allPaymentsSuccessful) {
      for (final entry in cart.entries) {
        final product = entry.key;
        final qty = entry.value;
        final newSupply = product.supply - qty;
        await FirebaseFirestore.instance.collection('products').doc(product.id).update({'supply': newSupply});
      }
      setState(() => cart.clear());
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Checkout complete!')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Payment failed. Try again.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Student Deals'),
        actions: [
          Stack(
            children: [
              IconButton(
                icon: const Icon(Icons.shopping_cart),
                onPressed: () => showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: const Text('Cart'),
                    content: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: cart.entries.map((e) => Text('${e.key.title} x${e.value}')).toList(),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Close'),
                      ),
                      ElevatedButton(
                        onPressed: checkout,
                        child: const Text('Checkout'),
                      ),
                    ],
                  ),
                ),
              ),
              if (cart.isNotEmpty)
                Positioned(
                  right: 8,
                  top: 8,
                  child: CircleAvatar(
                    radius: 8,
                    backgroundColor: Colors.red,
                    child: Text(
                      '${cart.length}',
                      style: const TextStyle(fontSize: 10, color: Colors.white),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text('Student Deals Menu',
                  style: TextStyle(color: Colors.white, fontSize: 24)),
            ),
            ListTile(
              leading: const Icon(Icons.local_offer),
              title: const Text('Student Deals'),
              selected: ModalRoute.of(context)?.settings.name == '/student-deals',
              selectedTileColor: Colors.grey[300],
              onTap: () {
                Navigator.pop(context);
                if (ModalRoute.of(context)?.settings.name != '/student-deals') {
                  Navigator.pushReplacementNamed(context, '/student-deals');
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.dashboard),
              title: const Text('Admin Dashboard'),
              selected: ModalRoute.of(context)?.settings.name == '/admin',
              selectedTileColor: Colors.grey[300],
              onTap: () {
                Navigator.pop(context);
                if (ModalRoute.of(context)?.settings.name != '/admin') {
                  Navigator.pushReplacementNamed(context, '/admin');
                }
              },
            ),
          ],
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('products').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final products = snapshot.data!.docs.map((doc) => Product.fromMap(doc.data() as Map<String, dynamic>)).toList();
          final filtered = products.where((p) {
            return (selectedSectors.isEmpty || selectedSectors.any((s) => p.sector.contains(s))) &&
                   (selectedLocations.isEmpty || selectedLocations.any((l) => p.location.contains(l))) &&
                   (selectedModes.isEmpty || selectedModes.any((m) => p.mode.contains(m)));
          }).toList();

          return ListView.builder(
            itemCount: filtered.length,
            itemBuilder: (_, i) {
              final p = filtered[i];
              return Card(
                child: ListTile(
                  title: Text(p.title),
                  subtitle: Text('${p.price} • ${p.supply} left'),
                  trailing: IconButton(
                    icon: const Icon(Icons.add_shopping_cart),
                    onPressed: p.supply > 0 ? () => addToCart(p) : null,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
