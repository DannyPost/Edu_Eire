import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

import 'studentdeals/admin_auth_page.dart';
import 'studentdeals/admin_dashboard.dart';
import 'studentdeals/student_deals_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: 'assets/config.env');

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const StudentDealsApp());
}

class StudentDealsApp extends StatelessWidget {
  const StudentDealsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Student Deals',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const AdminAuthPage(),
        '/admin': (context) => const AdminDashboard(),
        '/student-deals': (context) {
          final adminId = ModalRoute.of(context)!.settings.arguments as String?;
          return StudentDealsPage(adminId: adminId);
        },
      },
    );
  }
}
